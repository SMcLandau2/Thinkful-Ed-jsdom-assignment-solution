module.exports = {
  preset: "jest-puppeteer",
};
